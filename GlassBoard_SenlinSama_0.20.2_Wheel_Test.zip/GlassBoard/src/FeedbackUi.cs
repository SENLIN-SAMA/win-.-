using System;using System.IO;using System.Linq;using System.Diagnostics;using System.Runtime.InteropServices;using System.Text;using System.Windows;using System.Windows.Controls;
namespace GlassBoard {
    public static class FileShellActions {
        [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)] struct SHELLEXECUTEINFO{public int Size;public uint Mask;public IntPtr Window;[MarshalAs(UnmanagedType.LPWStr)]public string Verb,File,Parameters,Directory;public int Show;public IntPtr Instance,IdList;[MarshalAs(UnmanagedType.LPWStr)]public string Class;public IntPtr ClassKey;public uint Hotkey;public IntPtr Icon,Process;}
        [DllImport("shell32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern bool ShellExecuteEx(ref SHELLEXECUTEINFO info);
        public static void Properties(string path){var info=new SHELLEXECUTEINFO{Size=Marshal.SizeOf(typeof(SHELLEXECUTEINFO)),Mask=0x0000000C,Verb="properties",File=path,Show=1};if(!ShellExecuteEx(ref info))throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());}
        public static void Location(Entry entry){LaunchInfoService.Enrich(entry);string path=!string.IsNullOrWhiteSpace(entry.LaunchTarget)&&File.Exists(entry.LaunchTarget)?entry.LaunchTarget:entry.Path;if(Directory.Exists(path))Process.Start(new ProcessStartInfo("explorer.exe","\""+path+"\""){UseShellExecute=true});else if(File.Exists(path))Process.Start(new ProcessStartInfo("explorer.exe","/select,\""+path+"\""){UseShellExecute=true});else throw new FileNotFoundException("文件已移动或删除",path);}
    }
    public static class FullscreenState {
        [StructLayout(LayoutKind.Sequential)]struct RECT{public int Left,Top,Right,Bottom;}
        [StructLayout(LayoutKind.Sequential)]struct MONITORINFO{public int Size;public RECT Monitor,Work;public uint Flags;}
        [DllImport("user32.dll")]static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")]static extern bool IsIconic(IntPtr window);
        [DllImport("user32.dll")]static extern bool IsWindowVisible(IntPtr window);
        [DllImport("user32.dll")]static extern bool GetWindowRect(IntPtr window,out RECT rect);
        [DllImport("user32.dll")]static extern IntPtr MonitorFromWindow(IntPtr window,uint flags);
        [DllImport("user32.dll",CharSet=CharSet.Unicode)]static extern bool GetMonitorInfo(IntPtr monitor,ref MONITORINFO info);
        [DllImport("user32.dll",CharSet=CharSet.Unicode)]static extern int GetClassName(IntPtr window,StringBuilder text,int length);
        [DllImport("user32.dll")]static extern uint GetWindowThreadProcessId(IntPtr window,out uint id);
        public static bool Active(){return Active(IntPtr.Zero);}
        public static bool Active(IntPtr onMonitor){
            var window=GetForegroundWindow();
            if(window==IntPtr.Zero||IsIconic(window)||!IsWindowVisible(window))return false;
            var display=MonitorFromWindow(window,2);
            if(onMonitor!=IntPtr.Zero&&display!=MonitorFromWindow(onMonitor,2))return false;
            uint pid;GetWindowThreadProcessId(window,out pid);
            if(pid==(uint)Process.GetCurrentProcess().Id)return false;
            var cls=new StringBuilder(256);GetClassName(window,cls,256);
            if(new[]{"Progman","WorkerW","Shell_TrayWnd","Shell_SecondaryTrayWnd"}.Contains(cls.ToString()))return false;
            RECT rect;var monitor=new MONITORINFO{Size=Marshal.SizeOf(typeof(MONITORINFO))};
            if(!GetWindowRect(window,out rect)||!GetMonitorInfo(display,ref monitor))return false;
            return rect.Left<=monitor.Monitor.Left&&rect.Top<=monitor.Monitor.Top&&rect.Right>=monitor.Monitor.Right&&rect.Bottom>=monitor.Monitor.Bottom;
        }
    }
    public partial class Controller {
        bool removalMigrated,glassSuppressed;
        public bool GlassSuppressed{get{return glassSuppressed;}}
        void MigrateRemovalIdentities(){if(removalMigrated)return;removalMigrated=true;foreach(var entry in Prefs.Apps.Where(a=>string.IsNullOrWhiteSpace(a.LaunchTarget)))try{LaunchInfoService.Enrich(entry);}catch{}foreach(string path in Prefs.Removed.ToList())if(!Prefs.Apps.Any(a=>string.Equals(a.Path,path,StringComparison.OrdinalIgnoreCase))&&(File.Exists(path)||Directory.Exists(path)))try{var removed=LaunchInfoService.Read(path);if(!Prefs.Apps.Any(a=>RemovalRules.Same(a,removed)))RemovalRules.Remember(Prefs,removed);}catch{}RemovalRules.ReconcileActive(Prefs);Save();}
        public void ChooseDockFiles(){bool busy=Board.ModalBusy;Board.ModalBusy=true;try{var pick=new Microsoft.Win32.OpenFileDialog{Title="添加软件或文件到 Dock",Multiselect=true,Filter="所有文件|*.*"};if(pick.ShowDialog(OwnerWindow)!=true)return;Add(pick.FileNames,true,"全部");var before=BeginBoardEdit();foreach(string path in pick.FileNames){var entry=Prefs.Apps.FirstOrDefault(a=>string.Equals(a.Path,EntryPathRules.Normalize(path),StringComparison.OrdinalIgnoreCase));if(entry!=null&&!entry.Pinned&&Prefs.Apps.Count(a=>a.Pinned)<20)entry.Pinned=true;}EndBoardEdit(before,"添加到 Dock");Refresh();}finally{Board.ModalBusy=busy;}}
        public void SetGameMode(bool enabled){Prefs.GameMode=enabled;Save();ApplyGameMode();RefreshTrayMenu();}
        public void CheckGameMode(){if(!Prefs.AutoGameMode&&!Prefs.GameMode&&!glassSuppressed)return;ApplyGameMode();}
        public void ApplyGameMode(){Dock.GamePolling(Prefs.AutoGameMode);bool suppress=GameModeRules.Suppressed(Prefs.GameMode,Prefs.AutoGameMode,Prefs.AutoGameMode&&FullscreenState.Active(),false);if(suppress==glassSuppressed)return;glassSuppressed=suppress;ControlCenterVisibility(!suppress);if(suppress){Board.Hide();Dock.Hide();if(widgets!=null)widgets.SetVisible(false);}else{Dock.Refresh(false);Dock.Show();if(widgets!=null)widgets.SetVisible(true);}if(Tray!=null)RefreshTrayMenu();}
        void BuildGameSettings(StackPanel panel){panel.Children.Add(new TextBlock{Text="游戏模式",FontSize=18,Margin=new Thickness(0,22,0,10)});var manual=new CheckBox{Content="游戏模式：隐藏 Dock、大面板和小组件",IsChecked=Prefs.GameMode,Margin=new Thickness(0,6,0,8)};panel.Children.Add(manual);manual.Checked+=(s,e)=>SetGameMode(true);manual.Unchecked+=(s,e)=>SetGameMode(false);var automatic=new CheckBox{Content="检测全屏应用时自动进入（默认关闭）",IsChecked=Prefs.AutoGameMode,Margin=new Thickness(0,6,0,8)};panel.Children.Add(automatic);automatic.Checked+=(s,e)=>{Prefs.AutoGameMode=true;Save();ApplyGameMode();};automatic.Unchecked+=(s,e)=>{Prefs.AutoGameMode=false;Save();ApplyGameMode();};panel.Children.Add(new TextBlock{Text="游戏模式期间玻璃窗口完全隐藏，避免触碰底边误唤醒。右键系统托盘可退出；自动模式离开全屏后恢复 Dock 和组件。组件配置不关闭或清空。",TextWrapping=TextWrapping.Wrap});}
    }
}

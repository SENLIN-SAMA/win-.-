using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace GlassBoard {
    internal static class DockSystemIcons {
        internal const string Add="add";
        static readonly Dictionary<string,Geometry> Symbols=new Dictionary<string,Geometry>{
            {DockLayoutRules.Apps,Shape("M 4,4 H 8 V 8 H 4 Z M 10,4 H 14 V 8 H 10 Z M 16,4 H 20 V 8 H 16 Z M 4,10 H 8 V 14 H 4 Z M 10,10 H 14 V 14 H 10 Z M 16,10 H 20 V 14 H 16 Z M 4,16 H 8 V 20 H 4 Z M 10,16 H 14 V 20 H 10 Z M 16,16 H 20 V 20 H 16 Z")},
            {DockLayoutRules.Computer,Shape("M 4,4 H 20 A 1,1 0 0 1 21,5 V 15 A 1,1 0 0 1 20,16 H 4 A 1,1 0 0 1 3,15 V 5 A 1,1 0 0 1 4,4 Z M 12,16 V 20 M 8,20 H 16")},
            {DockLayoutRules.Power,Shape("M 12,3 V 11 M 7,6 A 8,8 0 1 0 17,6")},
            {DockLayoutRules.Network,Shape("M 4,7 H 11 M 15,7 H 20 M 11,7 A 2,2 0 1 1 15,7 A 2,2 0 1 1 11,7 M 4,17 H 8 M 12,17 H 20 M 8,17 A 2,2 0 1 1 12,17 A 2,2 0 1 1 8,17")},
            {DockLayoutRules.Settings,Shape("M 10,3 H 14 L 15,6 L 18,6 L 21,9 L 19,12 L 21,15 L 18,18 H 15 L 14,21 H 10 L 9,18 H 6 L 3,15 L 5,12 L 3,9 L 6,6 H 9 Z M 8.5,12 A 3.5,3.5 0 1 1 15.5,12 A 3.5,3.5 0 1 1 8.5,12")},
            {DockLayoutRules.RecycleBin,Shape("M 4,7 H 20 M 9,7 V 4 H 15 V 7 M 6,7 L 7,20 H 17 L 18,7 M 10,10 V 17 M 14,10 V 17")},
            {Add,Shape("M 5,12 H 19 M 12,5 V 19")},
        };
        static readonly Dictionary<string,Color> Tints=new Dictionary<string,Color>{
            {DockLayoutRules.Apps,Color.FromRgb(66,119,231)},
            {DockLayoutRules.Computer,Color.FromRgb(22,131,185)},
            {DockLayoutRules.Power,Color.FromRgb(198,69,86)},
            {DockLayoutRules.Network,Color.FromRgb(115,87,207)},
            {DockLayoutRules.Settings,Color.FromRgb(92,104,127)},
            {DockLayoutRules.RecycleBin,Color.FromRgb(33,137,103)},
            {Add,Color.FromRgb(57,111,201)},
        };

        static Geometry Shape(string path){var shape=Geometry.Parse(path);shape.Freeze();return shape;}

        internal static FrameworkElement Create(string key,int style,bool light,double size,Brush foreground){
            Geometry geometry;
            if(key==null||!Symbols.TryGetValue(key,out geometry)||(style==0&&key!=DockLayoutRules.Power))return null;
            bool badge=style>=2;
            var drawing=new Canvas{Width=24,Height=24};
            drawing.Children.Add(new Path{Data=geometry,Stroke=style==3?Brushes.White:foreground,
                StrokeThickness=1.65,StrokeStartLineCap=PenLineCap.Round,StrokeEndLineCap=PenLineCap.Round,
                StrokeLineJoin=PenLineJoin.Round});
            var glyph=new Viewbox{Width=size*(badge?.61:.75),Height=size*(badge?.61:.75),Child=drawing};
            if(!badge)return new Grid{Width=size,Height=size,Children={glyph}};
            Brush background=Polish.Color(light?"#B8FFFFFF":"#7752647B");
            if(style==3){
                var tint=Tints[key];
                var gradient=new LinearGradientBrush(Color.Multiply(tint,1.25f),tint,58);
                gradient.Freeze();background=gradient;
            }
            return new Border{Width=size,Height=size,CornerRadius=new CornerRadius(size*.26),Background=background,
                BorderThickness=new Thickness(1),BorderBrush=Polish.Color(light?"#75FFFFFF":"#50FFFFFF"),Child=glyph};
        }
    }
}

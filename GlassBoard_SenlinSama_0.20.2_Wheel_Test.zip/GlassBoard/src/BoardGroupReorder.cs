using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace GlassBoard {
    public partial class BoardWindow {
        const string GroupDragFormat="GlassBoard.GroupOrder";
        string groupDragSource,groupDropTarget;
        bool groupDropBefore;
        Border groupDropMarker;
        TranslateTransform groupDropPosition;

        void BindGroupFolder(Border folder,string name){
            if(name=="全部"||name=="未分组"){
                folder.MouseLeftButtonUp+=(s,e)=>{OpenGroup(name);e.Handled=true;};
                return;
            }

            folder.ToolTip="点击打开 · 拖动分组调整顺序 · 可把应用拖入分组";
            Point? press=null;
            folder.PreviewMouseLeftButtonDown+=(s,e)=>{
                if(folder.CaptureMouse())press=e.GetPosition(folder);
            };
            folder.LostMouseCapture+=(s,e)=>press=null;
            folder.PreviewMouseLeftButtonUp+=(s,e)=>{
                if(!press.HasValue)return;
                press=null;folder.ReleaseMouseCapture();
                if(new Rect(folder.RenderSize).Contains(e.GetPosition(folder)))OpenGroup(name);
                e.Handled=true;
            };
            folder.PreviewMouseMove+=(s,e)=>{
                if(!press.HasValue||e.LeftButton!=MouseButtonState.Pressed)return;
                var current=e.GetPosition(folder);
                if(Math.Abs(current.X-press.Value.X)<SystemParameters.MinimumHorizontalDragDistance&&
                   Math.Abs(current.Y-press.Value.Y)<SystemParameters.MinimumVerticalDragDistance)return;
                press=null;folder.ReleaseMouseCapture();
                e.Handled=true;
                DragGroupFolder(folder,name);
            };

            folder.PreviewDragOver+=(s,e)=>{
                if(groupDragSource==null||!e.Data.GetDataPresent(GroupDragFormat))return;
                e.Handled=true;e.Effects=DragDropEffects.None;
                if(name==groupDragSource){groupDropMarker.Visibility=Visibility.Collapsed;return;}
                bool before=e.GetPosition(folder).X<folder.ActualWidth/2;
                var point=folder.TranslatePoint(new Point(before?0:folder.ActualWidth-2,5),Root);
                groupDropPosition.X=point.X;groupDropPosition.Y=point.Y;
                groupDropMarker.Height=Math.Max(1,folder.ActualHeight-10);
                groupDropMarker.Visibility=Visibility.Visible;
                e.Effects=DragDropEffects.Move;
            };
            folder.DragLeave+=(s,e)=>{
                if(groupDropMarker!=null&&e.Data.GetDataPresent(GroupDragFormat))
                    groupDropMarker.Visibility=Visibility.Collapsed;
            };
            folder.PreviewDrop+=(s,e)=>{
                if(groupDragSource==null||!e.Data.GetDataPresent(GroupDragFormat))return;
                e.Handled=true;e.Effects=DragDropEffects.None;
                if(name==groupDragSource)return;
                groupDropTarget=name;
                groupDropBefore=e.GetPosition(folder).X<folder.ActualWidth/2;
                e.Effects=DragDropEffects.Move;
            };
        }

        void DragGroupFolder(Border folder,string name){
            groupDragSource=name;groupDropTarget=null;
            bool wasBusy=ModalBusy;ModalBusy=true;
            groupDropPosition=new TranslateTransform();
            groupDropMarker=new Border{Width=2,Background=Polish.Accent,CornerRadius=new CornerRadius(1),
                IsHitTestVisible=false,Visibility=Visibility.Collapsed,HorizontalAlignment=HorizontalAlignment.Left,
                VerticalAlignment=VerticalAlignment.Top,RenderTransform=groupDropPosition};
            Root.Children.Add(groupDropMarker);
            var effect=DragDropEffects.None;
            try{
                effect=DragDrop.DoDragDrop(folder,new DataObject(GroupDragFormat,name),DragDropEffects.Move);
            }catch(Exception ex){Store.Log(ex);}
            finally{
                Root.Children.Remove(groupDropMarker);
                groupDropMarker=null;groupDropPosition=null;groupDragSource=null;ModalBusy=wasBusy;
            }
            string target=groupDropTarget;groupDropTarget=null;
            if(effect!=DragDropEffects.Move||target==null)return;
            var before=C.BeginBoardEdit();
            if(!FeatureRules.ReorderGroup(C.Prefs.Groups,name,target,groupDropBefore))return;
            C.EndBoardEdit(before,"调整分组顺序");
            SyncGroups();RefreshFolders();UpdateSelectionBar();
            SetStatus("分组顺序已保存 · Ctrl+Z 撤销");
        }
    }
}

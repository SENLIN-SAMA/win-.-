using System;using System.Collections.Generic;using System.Linq;using System.IO;using System.Text;using System.Diagnostics;using System.Runtime.Serialization;using System.Runtime.Serialization.Json;using System.Threading.Tasks;using System.Windows.Media;using System.Windows.Media.Imaging;using System.Windows.Threading;
namespace GlassBoard {
    [DataContract] public class MediaSnapshot {
        [DataMember] public bool Available,Playing,CanSeek,CanPrevious,CanNext,CanToggle;
        [DataMember] public string Status,Title,Artist,Album,Source,Key,Cover,Backend,CoverStatus,MetadataStatus,TimelineStatus;
        [DataMember] public double Position,Duration,Age,MinSeek,MaxSeek;
        [DataMember] public double Rate=1;
        [OnDeserializing] void Defaults(StreamingContext context){Rate=1;}
        public MediaSnapshot Copy(){return (MediaSnapshot)MemberwiseClone();}
    }
    public static class MediaFallback {
        public static MediaSnapshot Merge(MediaSnapshot standard,MediaSnapshot extra){if(standard==null)return new MediaSnapshot();var result=standard.Copy();if(!standard.Available||extra==null||!extra.Available||string.IsNullOrEmpty(standard.Key)||standard.Key!=extra.Key||standard.Source!=extra.Source)return result;if(string.IsNullOrEmpty(result.Cover)&&!string.IsNullOrEmpty(extra.Cover)){result.Cover=extra.Cover;result.CoverStatus=extra.CoverStatus;}if(extra.Duration>0&&!double.IsNaN(extra.Duration)&&!double.IsInfinity(extra.Duration)&&(result.Duration<=0||(!result.CanSeek&&extra.CanSeek))){result.Duration=extra.Duration;result.Position=extra.Position;result.MinSeek=extra.MinSeek;result.MaxSeek=extra.MaxSeek;result.Age=extra.Age;result.Rate=extra.Rate;result.CanSeek=extra.CanSeek;result.TimelineStatus=extra.TimelineStatus;result.Backend=extra.Backend=="Netease UIA"?extra.Backend:"NPSMLib isolated";}return result;}
    }
    [DataContract] public class MediaRequest {[DataMember]public string Command;[DataMember]public double Seconds;[DataMember]public string Key;[DataMember]public string Source,Title,Artist,Album;[DataMember]public bool Playing,UseNative,CoverOnly;}
    public static class MediaWireProtocol {
        public static void Write(Stream stream,object value){using(var buffer=new MemoryStream()){new DataContractJsonSerializer(value.GetType()).WriteObject(buffer,value);byte[] bytes=buffer.ToArray();stream.Write(bytes,0,bytes.Length);stream.WriteByte(10);stream.Flush();}}
        public static MediaRequest ReadRequest(string line){using(var buffer=new MemoryStream(Encoding.UTF8.GetBytes(line)))return (MediaRequest)new DataContractJsonSerializer(typeof(MediaRequest)).ReadObject(buffer);}
        public static void Loop(TextReader input,Stream output,Func<MediaRequest,MediaSnapshot> read){string line;while((line=input.ReadLine())!=null){MediaRequest request=null;MediaSnapshot result;try{request=ReadRequest(line);if(request.Command=="exit")break;result=read(request);}catch(Exception ex){result=new MediaSnapshot{Key=request==null?null:request.Key,Source=request==null?null:request.Source,Backend="Netease UIA",Status=ex.Message};}Write(output,result);}}
    }
    public sealed class MediaSessionBridge:IDisposable {
        readonly bool nativeOnly,neteaseOnly;
        readonly System.Threading.Timer idle;
        const int WorkerIdleMilliseconds=45000;
        long lastUse;
        public MediaSessionBridge(bool native=false,bool netease=false){
            nativeOnly=native;neteaseOnly=netease;
            idle=new System.Threading.Timer(_=>TrimIdle(),null,System.Threading.Timeout.Infinite,System.Threading.Timeout.Infinite);
        }
        public bool UseNative,ArtworkOnly;Process process;readonly object gate=new object();volatile bool stopped;DateTime retry=DateTime.MinValue;string lastFailure="";readonly object errorGate=new object();string stderr="";
        public Task<MediaSnapshot> Send(string command,double seconds=0,string key=null,MediaSnapshot hint=null){return Task.Run(()=>{lock(gate){if(stopped)return new MediaSnapshot{Status="播放器已关闭"};try{
            if(process==null||process.HasExited){if(DateTime.UtcNow<retry)return new MediaSnapshot{Status="等待后台读取重试："+lastFailure};Start();}
            var request=new MediaRequest{Command=command,Seconds=seconds,Key=key,UseNative=UseNative,CoverOnly=ArtworkOnly,Source=hint==null?null:hint.Source,Title=hint==null?null:hint.Title,Artist=hint==null?null:hint.Artist,Album=hint==null?null:hint.Album,Playing=hint!=null&&hint.Playing};MediaWireProtocol.Write(process.StandardInput.BaseStream,request);
            var read=process.StandardOutput.ReadLineAsync();if(!read.Wait(nativeOnly||neteaseOnly?7000:15000))throw new TimeoutException("系统媒体读取超时");string line=read.Result;if(line==null){string detail;lock(errorGate)detail=stderr;throw new IOException("后台读取进程已退出"+(process.HasExited?"（"+process.ExitCode+"）":"")+(string.IsNullOrWhiteSpace(detail)?"":"："+detail.Trim()));}if(line.Length>12000000)throw new InvalidDataException("封面数据过大");using(var s=new MemoryStream(Encoding.UTF8.GetBytes(line)))return (MediaSnapshot)new DataContractJsonSerializer(typeof(MediaSnapshot)).ReadObject(s);
        }catch(Exception ex){lastFailure=ex.GetType().Name+"："+ex.Message;Kill();retry=DateTime.UtcNow.AddSeconds(5);return new MediaSnapshot{Status=lastFailure};}
        finally{
            lastUse=Stopwatch.GetTimestamp();
            if(process!=null&&!stopped)
                try{idle.Change(WorkerIdleMilliseconds,System.Threading.Timeout.Infinite);}catch(ObjectDisposedException){}
        }}});}
        void TrimIdle(){
            if(!System.Threading.Monitor.TryEnter(gate))return;
            try{
                if(stopped||process==null)return;
                double remaining=WorkerIdleMilliseconds-(Stopwatch.GetTimestamp()-lastUse)*1000.0/Stopwatch.Frequency;
                if(remaining<=0)Kill();
                else idle.Change((int)Math.Ceiling(remaining),System.Threading.Timeout.Infinite);
            }catch(ObjectDisposedException){}catch(Exception ex){Store.Log(ex);}
            finally{System.Threading.Monitor.Exit(gate);}
        }
        void Start(){
            Kill();string name=nativeOnly?"NativeMediaBridge.ps1":"MediaBridge.ps1";
            string executable=System.Reflection.Assembly.GetExecutingAssembly().Location;
            string resource="GlassBoard."+name;string command;
            using(var embedded=System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(resource)){
                if(embedded!=null){
                    command="$a=[Reflection.Assembly]::LoadFile('"+executable.Replace("'","''")+"');$r=New-Object IO.StreamReader($a.GetManifestResourceStream('"+resource+"'));try{$s=$r.ReadToEnd()}finally{$r.Dispose()};& ([ScriptBlock]::Create($s))";
                }else{
                    string script=System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"src",name);
                    if(!neteaseOnly&&!File.Exists(script))throw new FileNotFoundException("音乐读取模块缺失；主程序内置模块和外部脚本均不可用："+script,script);
                    command="& '"+script.Replace("'","''")+"'";
                }
            }
            var p=new ProcessStartInfo{FileName=neteaseOnly?executable:System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),"WindowsPowerShell","v1.0","powershell.exe"),Arguments=neteaseOnly?"--netease-ui-bridge":"-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand "+Convert.ToBase64String(Encoding.Unicode.GetBytes(command)),UseShellExecute=false,CreateNoWindow=true,RedirectStandardInput=true,RedirectStandardOutput=true,RedirectStandardError=true,StandardOutputEncoding=Encoding.UTF8,StandardErrorEncoding=Encoding.UTF8};
            p.EnvironmentVariables["GLASSBOARD_HOME"]=AppDomain.CurrentDomain.BaseDirectory;
            lock(errorGate)stderr="";process=Process.Start(p);process.ErrorDataReceived+=(s,e)=>{if(!string.IsNullOrEmpty(e.Data))lock(errorGate){stderr+=e.Data+"\n";if(stderr.Length>2000)stderr=stderr.Substring(stderr.Length-2000);}};process.BeginErrorReadLine();
        }
        void Kill(){var p=process;process=null;if(p==null)return;try{if(!p.HasExited)p.Kill();}catch{}p.Dispose();}
        public void Dispose(){stopped=true;idle.Dispose();var p=process;try{if(p!=null&&!p.HasExited)p.Kill();}catch{}Task.Run(()=>{lock(gate)Kill();});}
    }
    public class TrackMetadata {
        public string Title,Artist,Album;public byte[] Cover;
        public static TrackMetadata Read(string path){var result=new TrackMetadata{Title=System.IO.Path.GetFileNameWithoutExtension(path),Artist="本地音乐"};try{
            using(var f=File.OpenRead(path)){byte[] header=new byte[10];if(f.Read(header,0,10)==10&&Encoding.ASCII.GetString(header,0,3)=="ID3"&&(header[3]==3||header[3]==4)&&(header[5]&0xC0)==0){int size=Sync(header,6);if(size>0&&size<=8*1024*1024){byte[] data=new byte[size];int used=0;while(used<size){int n=f.Read(data,used,size-used);if(n==0)break;used+=n;}int at=0;while(at+10<=used){string id=Encoding.ASCII.GetString(data,at,4);int count=header[3]==4?Sync(data,at+4):Big(data,at+4);if(count<=0||count>used-at-10)break;int start=at+10;bool plain=(data[at+8]==0&&data[at+9]==0);if(plain&&(id=="TIT2"||id=="TPE1"||id=="TALB")){string text=Text(data,start,count);if(!string.IsNullOrWhiteSpace(text)){if(id=="TIT2")result.Title=text;else if(id=="TPE1")result.Artist=text;else result.Album=text;}}else if(plain&&id=="APIC"&&result.Cover==null){int encoding=data[start],p=start+1,end=start+count;while(p<end&&data[p]!=0)p++;p+=2;if(encoding==1||encoding==2){while(p+1<end&&(data[p]!=0||data[p+1]!=0))p+=2;p+=2;}else{while(p<end&&data[p]!=0)p++;p++;}if(p<end&&end-p<=4*1024*1024){result.Cover=new byte[end-p];Buffer.BlockCopy(data,p,result.Cover,0,end-p);}}at=start+count;}}}}
            if(result.Cover==null){string folder=System.IO.Path.GetDirectoryName(path);foreach(string name in new string[]{System.IO.Path.GetFileNameWithoutExtension(path)+".jpg",System.IO.Path.GetFileNameWithoutExtension(path)+".png","cover.jpg","cover.png","folder.jpg"}){string cover=System.IO.Path.Combine(folder,name);if(File.Exists(cover)&&new FileInfo(cover).Length<=4*1024*1024){result.Cover=File.ReadAllBytes(cover);break;}}}
        }catch{}return result;}
        static int Sync(byte[] b,int p){return ((b[p]&127)<<21)|((b[p+1]&127)<<14)|((b[p+2]&127)<<7)|(b[p+3]&127);}
        static int Big(byte[] b,int p){return (b[p]<<24)|(b[p+1]<<16)|(b[p+2]<<8)|b[p+3];}
        static string Text(byte[] b,int p,int count){if(count<2)return "";var encoding=b[p]==1?Encoding.Unicode:b[p]==2?Encoding.BigEndianUnicode:b[p]==3?Encoding.UTF8:Encoding.GetEncoding(28591);return encoding.GetString(b,p+1,count-1).Trim('\0','\uFEFF',' ','\r','\n');}
    }
    public sealed class MusicEngine:IDisposable {
        readonly Controller C;MediaPlayer player;readonly MediaSessionBridge bridge=new MediaSessionBridge{ArtworkOnly=true};readonly MediaSessionBridge nativeBridge=new MediaSessionBridge(true){ArtworkOnly=true};MediaSnapshot nativeCache;DateTime nativeAt=DateTime.MinValue,lastNative=DateTime.MinValue;string nativeStatus="尚未尝试",primaryStatus="尚未尝试";MediaSnapshot discovered;DateTime discoveredAt=DateTime.MinValue,lastDiscovery=DateTime.MinValue,nextPrimary=DateTime.MinValue;readonly DispatcherTimer timer=new DispatcherTimer{Interval=TimeSpan.FromSeconds(1)};readonly Random random=new Random();bool stopped,polling,opened,playing;int metadataVersion;DateTime lastPoll=DateTime.MinValue;string systemKey="",loadedPath="";bool loadedLocal;DateTime sessionAt=DateTime.UtcNow,seekUntil=DateTime.MinValue;double? seekTarget;readonly MediaSeekQueue seeks=new MediaSeekQueue();string iconSource="";
        public event Action Changed;
        public string Title="等待音乐",Artist="选择本地音乐，或在播放器中开始播放",Album="",Status="";
        public ImageSource Artwork,AppIcon;readonly TrackArtworkCache<ImageSource> artworkCache=new TrackArtworkCache<ImageSource>(4);DateTime lastAvailable=DateTime.MinValue,stableMetadataAt=DateTime.MinValue;MediaSnapshot stableMetadata;string lastCoverFingerprint="";public MediaSnapshot Session=new MediaSnapshot();
        public bool Local{get{return C.Prefs.Widgets.MusicMode=="local";}}
        public bool Playing{get{return Local?playing:Session.Playing;}}
        public double Duration{get{return Local?(player!=null&&opened&&player.NaturalDuration.HasTimeSpan?player.NaturalDuration.TimeSpan.TotalSeconds:0):Session.Duration;}}
        public double Position{get{if(Local)return player!=null&&opened?player.Position.TotalSeconds:0;if(seekTarget.HasValue&&DateTime.UtcNow<seekUntil)return MediaTimeline.ClampSeek(seekTarget.Value,Session.MinSeek,Session.MaxSeek,Duration);return MediaTimeline.Position(Session.Position,Session.Duration,Session.Playing,Session.Rate,Session.Age+(DateTime.UtcNow-sessionAt).TotalSeconds);}}
        public bool CanSeek{get{return Local?player!=null&&opened&&player.NaturalDuration.HasTimeSpan:Session.Available&&Session.CanSeek&&Session.Duration>0;}}
        public MusicEngine(Controller c){
            C=c;
            timer.Tick+=(s,e)=>{
                if(stopped)return;
                bool visible=C.MusicVisible;
                timer.Interval=TimeSpan.FromSeconds(visible&&!Local?1:5);
                if(!visible||Local)return;
                if((DateTime.UtcNow-lastPoll).TotalSeconds>=BackgroundWorkRules.MediaPollSeconds(true,Session.Available,Session.Playing))Poll();
                DrainSeek();
            };
        }
        public void Wake(){if(stopped||Local||!C.MusicVisible)return;timer.Interval=TimeSpan.FromSeconds(1);Poll();}
        public void Start(){if(stopped||timer.IsEnabled)return;timer.Start();if(Local)Load(false);else Wake();}
        void EnsurePlayer(){if(player!=null)return;var candidate=new MediaPlayer();try{candidate.Volume=C.Prefs.Widgets.Volume;candidate.MediaOpened+=(s,e)=>{if(stopped)return;opened=true;Notify();};candidate.MediaFailed+=(s,e)=>{opened=false;playing=false;Status="此文件暂时无法播放，请检查音频格式";Notify();};candidate.MediaEnded+=(s,e)=>{if(!stopped&&Local)Advance(true);};player=candidate;}catch{candidate.Close();throw;}}
        void Notify(){if(!stopped&&Changed!=null)Changed();}
        public void Update(){bridge.UseNative=false;if(!C.Prefs.Widgets.AutoNativeMediaCompatibility&&!C.Prefs.Widgets.NativeMediaCompatibility){nativeCache=null;lastNative=DateTime.MinValue;}if(player!=null)player.Volume=C.Prefs.Widgets.Volume;var o=C.Prefs.Widgets;string path=o.Playlist.Count==0?"":o.Playlist[o.TrackIndex];if(loadedLocal!=Local){metadataVersion++;if(player!=null)player.Pause();playing=false;loadedLocal=Local;Artwork=null;if(Local)Load(false);else{systemKey="";stableMetadata=null;lastCoverFingerprint="";Poll();}}else if(Local&&loadedPath!=path)Load(false);Notify();}
        async void Load(bool autoplay){int version=++metadataVersion;var o=C.Prefs.Widgets;loadedLocal=true;loadedPath=o.Playlist.Count==0?"":o.Playlist[o.TrackIndex];if(o.Playlist.Count==0){if(player!=null)player.Close();Title="选择本地音乐";Artist="支持批量添加播放列表";Artwork=null;playing=false;opened=false;Notify();return;}string path=o.Playlist[o.TrackIndex];try{opened=false;EnsurePlayer();player.Open(new Uri(path));playing=autoplay;if(autoplay)player.Play();Title=System.IO.Path.GetFileNameWithoutExtension(path);Artist="本地音乐";Album="";Artwork=null;Status="";Notify();var data=await Task.Run(()=>TrackMetadata.Read(path));if(stopped||!Local||version!=metadataVersion)return;Title=data.Title;Artist=data.Artist;Album=data.Album;Artwork=Image(data.Cover);Notify();}catch(Exception ex){playing=false;Status=ex.Message;Notify();}}
        public void Pick(System.Windows.Window owner,bool append=false){var pick=new Microsoft.Win32.OpenFileDialog{Title=append?"添加到播放列表":"选择音乐，可多选",Multiselect=true,Filter="音频|*.mp3;*.wav;*.wma;*.m4a;*.aac;*.flac|所有文件|*.*"};if(pick.ShowDialog(owner)!=true)return;var o=C.Prefs.Widgets;bool keep=append&&Local&&o.Playlist.Count>0;if(append)o.Playlist=o.Playlist.Concat(pick.FileNames).Distinct(StringComparer.OrdinalIgnoreCase).ToList();else{o.Playlist=pick.FileNames.ToList();o.TrackIndex=0;}o.MusicMode="local";o.Normalize();C.Save();if(keep){Notify();return;}Load(true);}
        public void Mode(bool local){if(Local==local)return;seeks.Clear();seekTarget=null;metadataVersion++;if(player!=null)player.Pause();playing=false;C.Prefs.Widgets.MusicMode=local?"local":"system";loadedLocal=local;C.Save();Artwork=null;if(local)Load(false);else{Title="等待系统音乐";Artist="在支持媒体会话的播放器中开始播放";systemKey="";stableMetadata=null;lastCoverFingerprint="";Poll();}Notify();}
        public async void Action(string action){if(stopped)return;if(action!="toggle"){seeks.Clear();seekTarget=null;}try{if(Local){if(action=="toggle"){if(!opened){Load(true);return;}if(playing)player.Pause();else player.Play();playing=!playing;}else if(action=="previous"){var o=C.Prefs.Widgets;if(o.Playlist.Count==0)return;o.TrackIndex=(o.TrackIndex-1+o.Playlist.Count)%o.Playlist.Count;C.Save();Load(true);}else Advance(false);Notify();}else{while(polling&&!stopped&&!Local)await Task.Delay(50);if(stopped||Local)return;polling=true;try{bool direct=Session.Backend=="NPSMLib direct";var reply=direct?await nativeBridge.Send(action,0,Session.Key,Session):await bridge.Send(action);if(stopped||Local)return;if(direct)lastDiscovery=DateTime.MinValue;Accept(reply);if(!reply.Available&&!direct){SystemMedia.Key(action=="previous"?(ushort)0xB1:action=="next"?(ushort)0xB0:(ushort)0xB3);Status="已发送媒体键；系统曲目信息暂不可用";}}finally{polling=false;DrainSeek();}Notify();}}catch(Exception ex){Status=ex.Message;Notify();}}
        void Advance(bool ended){var o=C.Prefs.Widgets;int next=WidgetRules.NextTrack(o.TrackIndex,o.Playlist.Count,o.RepeatMode,o.Shuffle,random.Next(),ended);if(next<0){playing=false;if(player!=null)player.Stop();Notify();return;}o.TrackIndex=next;C.Save();Load(true);}
        public void Select(int index){var o=C.Prefs.Widgets;if(index<0||index>=o.Playlist.Count)return;o.TrackIndex=index;o.MusicMode="local";C.Save();Load(true);}
        public void Remove(int index){var o=C.Prefs.Widgets;if(index<0||index>=o.Playlist.Count)return;bool current=index==o.TrackIndex;o.Playlist.RemoveAt(index);if(index<o.TrackIndex)o.TrackIndex--;o.Normalize();C.Save();if(current&&Local)Load(false);Notify();}
        public void Seek(double seconds){if(!CanSeek){Status=Duration>0?"播放器未开放进度调整":"播放器未提供时间轴";Notify();return;}seconds=Local?LayoutRules.Clamp(seconds,0,Duration,0):MediaTimeline.ClampSeek(seconds,Session.MinSeek,Session.MaxSeek,Duration);if(Local){try{player.Position=TimeSpan.FromSeconds(seconds);}catch(Exception ex){Status="无法调整播放进度："+ex.Message;}Notify();return;}seeks.Put(seconds,Session.Key);seekTarget=seconds;seekUntil=DateTime.UtcNow.AddSeconds(5);Notify();DrainSeek();}
        async void DrainSeek(){if(stopped||Local||polling)return;double seconds;if(!seeks.Take(Session.Key,out seconds))return;string key=Session.Key;polling=true;try{bool isolated=Session.Backend=="NPSMLib isolated";var reply=isolated?await nativeBridge.Send("seek",seconds,key,Session):await bridge.Send("seek",seconds,key);if(isolated&&reply!=null&&reply.Available){nativeCache=reply;nativeAt=DateTime.UtcNow;var merged=MediaFallback.Merge(Session,reply);merged.Status=reply.Status;reply=merged;}if(stopped||Local)return;bool same=reply!=null&&reply.Key==key;if(same&&reply.Available&&reply.Status=="OK"){Accept(reply);seekTarget=seconds;seekUntil=DateTime.UtcNow.AddSeconds(1.5);Status="";}else{seekTarget=null;Accept(reply);Status=same?"播放器拒绝调整进度":"曲目或播放器已切换，请重试";}Notify();}catch(Exception ex){seekTarget=null;Status="无法调整播放进度："+ex.Message;Notify();}finally{polling=false;if(!stopped&&!Local)DrainSeek();}}
        public void SetVolume(double value,bool save=true){C.Prefs.Widgets.Volume=LayoutRules.Clamp(value,0,1,.6);if(player!=null)player.Volume=C.Prefs.Widgets.Volume;if(save)C.Save();Notify();}
        public void SystemVolume(bool up){try{SystemMedia.Key(up?(ushort)0xAF:(ushort)0xAE);}catch(Exception ex){Status=ex.Message;}Notify();}
        public void Repeat(){C.Prefs.Widgets.RepeatMode=(C.Prefs.Widgets.RepeatMode+1)%3;C.Save();Notify();}
        public void Shuffle(){C.Prefs.Widgets.Shuffle=!C.Prefs.Widgets.Shuffle;C.Save();Notify();}
        DateTime lastArtworkPoll=DateTime.MinValue;
        MediaSnapshot CachedSupplement(){if(nativeCache==null)return null;var data=nativeCache.Copy();data.Age+=Math.Max(0,(DateTime.UtcNow-nativeAt).TotalSeconds);return data;}
        async void Poll(){if(polling||stopped||Local)return;polling=true;lastPoll=DateTime.UtcNow;try{bool artwork=string.IsNullOrEmpty(systemKey)||(DateTime.UtcNow-lastArtworkPoll).TotalSeconds>=10;if(artwork)lastArtworkPoll=DateTime.UtcNow;bool primaryDue=DateTime.UtcNow>=nextPrimary;var data=!primaryDue?new MediaSnapshot{Status=primaryStatus}:await bridge.Send(artwork?"cover":"refresh")??new MediaSnapshot{Status="系统媒体桥未返回数据"};if(stopped||Local)return;primaryStatus=data.Status??"未返回状态";
            if(!data.Available||string.IsNullOrWhiteSpace(data.Title)){
                if((DateTime.UtcNow-lastDiscovery).TotalSeconds>=BackgroundWorkRules.MediaPollSeconds(C.MusicVisible,Session.Available,Session.Playing)){lastDiscovery=DateTime.UtcNow;var fallback=await nativeBridge.Send("discover");if(stopped||Local)return;nativeStatus=fallback==null?"未返回数据":fallback.Status;if(fallback!=null&&fallback.Available&&!string.IsNullOrWhiteSpace(fallback.Title)){discovered=fallback;discoveredAt=DateTime.UtcNow;if(primaryDue)nextPrimary=DateTime.UtcNow.AddSeconds(10);}else discovered=null;}
                if(discovered!=null&&(DateTime.UtcNow-discoveredAt).TotalSeconds<4){data=discovered.Copy();data.Age+=(DateTime.UtcNow-discoveredAt).TotalSeconds;}
                else data.Status="主通道："+primaryStatus+"；兼容通道："+nativeStatus;
            }else{discovered=null;nextPrimary=DateTime.MinValue;}
            bool changed=nativeCache!=null&&nativeCache.Key!=data.Key;if(changed)nativeCache=null;bool supplement=C.Prefs.Widgets.AutoNativeMediaCompatibility||C.Prefs.Widgets.NativeMediaCompatibility;Accept(supplement?MediaFallback.Merge(data,CachedSupplement()):data);Notify();bool missing=data.Available&&data.Backend!="NPSMLib direct"&&string.IsNullOrEmpty(data.Cover)&&Artwork==null;if(supplement&&missing&&(changed||(DateTime.UtcNow-lastNative).TotalSeconds>=30)){lastNative=DateTime.UtcNow;var extra=await nativeBridge.Send("cover",0,data.Key,data);if(stopped||Local||Session.Key!=data.Key)return;nativeStatus=extra==null?"未返回数据":extra.Available?extra.Status+"；封面："+extra.CoverStatus:extra.Status;if(extra!=null&&extra.Available&&extra.Key==data.Key){nativeCache=extra;nativeAt=DateTime.UtcNow;Accept(MediaFallback.Merge(data,extra));Notify();}}}catch(Exception ex){Status="音乐读取异常："+ex.GetBaseException().Message;Store.Log(ex);Notify();}finally{polling=false;}}
        public string Diagnostics(){var s=Session;return "GlassBoard v"+System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString(3)+"\n程序位置："+System.Reflection.Assembly.GetExecutingAssembly().Location+"\n主通道："+primaryStatus+"\n读取后端："+s.Backend+"\n播放器："+s.Source+"\n曲目："+Title+"\n封面："+s.CoverStatus+"\n曲目信息："+s.MetadataStatus+"\n封面补充："+C.Prefs.Widgets.AutoNativeMediaCompatibility+"\n兼容通道："+nativeStatus+"\n状态："+s.Status;}
        void Accept(MediaSnapshot data){sessionAt=DateTime.UtcNow;Session=MusicMetadataRecovery.Recover((DateTime.UtcNow-stableMetadataAt).TotalSeconds<5?stableMetadata:null,data??new MediaSnapshot());Status=Session.Available?(Session.Status!="OK"?"播放器暂不支持此操作":""):"系统媒体读取失败 · "+(Session.Status??"未获得会话");if(!Session.Available){if(!string.IsNullOrEmpty(systemKey)&&(DateTime.UtcNow-lastAvailable).TotalSeconds<5)return;Title="等待系统音乐";Artist="开始播放后显示曲名与封面";Artwork=null;AppIcon=null;iconSource="";seekTarget=null;systemKey="";return;}lastAvailable=DateTime.UtcNow;if(Session.MetadataStatus=="OK"){stableMetadata=Session.Copy();stableMetadataAt=DateTime.UtcNow;}Title=string.IsNullOrWhiteSpace(Session.Title)?"正在播放":Session.Title;Artist=string.IsNullOrWhiteSpace(Session.Artist)?"系统播放器":Session.Artist;Album=Session.Album??"";if(!string.IsNullOrEmpty(Session.MetadataStatus)&&Session.MetadataStatus!="OK")Status="曲目信息读取失败 · "+Session.MetadataStatus;if(Session.Key!=systemKey){systemKey=Session.Key;Artwork=artworkCache.Get(systemKey,DateTime.UtcNow);lastCoverFingerprint="";seekTarget=null;}if(iconSource!=(Session.Source??"")){iconSource=Session.Source??"";AppIcon=null;LoadAppIcon(iconSource);}if(!string.IsNullOrEmpty(Session.Cover)){string fingerprint=CoverFingerprint.Of(Session.Cover);if(fingerprint!=lastCoverFingerprint){try{var artwork=Image(Convert.FromBase64String(Session.Cover));if(artwork!=null){Artwork=artwork;lastCoverFingerprint=fingerprint;artworkCache.Put(systemKey,artwork,DateTime.UtcNow);}}catch{}}}}
        async void LoadAppIcon(string source){if(string.IsNullOrWhiteSpace(source))return;string path=await Task.Run(()=>{string best=null;int length=0;foreach(var process in Process.GetProcesses()){try{string name=process.ProcessName;if(name.Length>=3&&name.Length>length&&source.IndexOf(name,StringComparison.OrdinalIgnoreCase)>=0){string candidate=process.MainModule.FileName;if(File.Exists(candidate)){best=candidate;length=name.Length;}}}catch{}finally{process.Dispose();}}return best;});if(stopped||Local||iconSource!=source)return;try{if(path!=null)AppIcon=Native.Icon(path);}catch{}Notify();}
        public static ImageSource Image(byte[] bytes){if(bytes==null||bytes.Length==0)return null;try{return ThumbnailImages.Read(bytes,384);}catch{return null;}}
        public void Dispose(){stopped=true;metadataVersion++;timer.Stop();nativeBridge.Dispose();try{if(player!=null)player.Close();}finally{bridge.Dispose();Changed=null;}}
    }
}

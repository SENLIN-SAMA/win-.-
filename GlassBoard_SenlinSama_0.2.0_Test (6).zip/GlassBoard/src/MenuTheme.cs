using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace GlassBoard {
    // Popup chrome is themed explicitly: the Windows MenuItem template paints
    // submenu backgrounds with SystemColors even when the item text is themed.
    public sealed class MenuTheme {
        static readonly Dictionary<bool,MenuTheme> themes=new Dictionary<bool,MenuTheme>();
        readonly Style menu,item,separator;
        MenuTheme(bool light){
            // Token replacement keeps both templates on one palette.
            string background=light?"#FAFCFF":"#202B3D",ink=light?"#202635":"#F4F6FC",line=light?"#CFD7E5":"#48566D",hover=light?"#DFEAFE":"#3A5074";
            Func<string,string> palette=x=>x.Replace("@BG",background).Replace("@INK",ink).Replace("@LINE",line).Replace("@HOVER",hover);
            string itemXaml=@"<ControlTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' TargetType='MenuItem'>
<Grid>
 <Border x:Name='Chrome' xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml' Background='{TemplateBinding Background}' CornerRadius='6' Padding='{TemplateBinding Padding}'>
  <Grid>
   <Grid.ColumnDefinitions><ColumnDefinition Width='22'/><ColumnDefinition Width='*'/><ColumnDefinition Width='Auto'/><ColumnDefinition Width='16'/></Grid.ColumnDefinitions>
   <ContentPresenter x:Name='Icon' ContentSource='Icon' VerticalAlignment='Center' HorizontalAlignment='Center'/>
   <TextBlock x:Name='Check' Text='✓' Foreground='{TemplateBinding Foreground}' Visibility='Collapsed' VerticalAlignment='Center'/>
   <ContentPresenter Grid.Column='1' ContentSource='Header' RecognizesAccessKey='True' VerticalAlignment='Center' HorizontalAlignment='Left'/>
   <TextBlock Grid.Column='2' Text='{TemplateBinding InputGestureText}' Foreground='{TemplateBinding Foreground}' Opacity='.7' Margin='18,0,8,0' VerticalAlignment='Center'/>
   <Path x:Name='Arrow' Grid.Column='3' Data='M 0,0 L 4,4 L 0,8' Stroke='{TemplateBinding Foreground}' StrokeThickness='1.6' Visibility='Collapsed' VerticalAlignment='Center' HorizontalAlignment='Right'/>
  </Grid>
 </Border>
 <Popup x:Name='PART_Popup' xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml' Placement='Right' HorizontalOffset='-1' AllowsTransparency='True' Focusable='False' IsOpen='{Binding IsSubmenuOpen, RelativeSource={RelativeSource TemplatedParent}, Mode=TwoWay}'>
  <Border x:Name='SubmenuSurface' Background='@BG' BorderBrush='@LINE' BorderThickness='1' CornerRadius='10' Padding='5' TextElement.Foreground='@INK' SnapsToDevicePixels='True'>
   <ScrollViewer CanContentScroll='True' MaxHeight='420' VerticalScrollBarVisibility='Auto' HorizontalScrollBarVisibility='Disabled'>
    <ItemsPresenter Grid.IsSharedSizeScope='True'/>
   </ScrollViewer>
  </Border>
 </Popup>
</Grid>
<ControlTemplate.Triggers>
 <Trigger Property='HasItems' Value='True'><Setter TargetName='Arrow' Property='Visibility' Value='Visible'/></Trigger>
 <Trigger Property='IsChecked' Value='True'><Setter TargetName='Check' Property='Visibility' Value='Visible'/><Setter TargetName='Icon' Property='Visibility' Value='Collapsed'/></Trigger>
 <Trigger Property='IsHighlighted' Value='True'><Setter TargetName='Chrome' Property='Background' Value='@HOVER'/></Trigger>
 <Trigger Property='IsSubmenuOpen' Value='True'><Setter TargetName='Chrome' Property='Background' Value='@HOVER'/></Trigger>
 <Trigger Property='IsEnabled' Value='False'><Setter TargetName='Chrome' Property='Opacity' Value='.45'/></Trigger>
</ControlTemplate.Triggers>
</ControlTemplate>";
            item=new Style(typeof(MenuItem));
            item.Setters.Add(new Setter(Control.ForegroundProperty,Polish.Ink(light)));
            item.Setters.Add(new Setter(Control.BackgroundProperty,System.Windows.Media.Brushes.Transparent));
            item.Setters.Add(new Setter(Control.PaddingProperty,new Thickness(8,9,8,9)));
            item.Setters.Add(new Setter(Control.TemplateProperty,(ControlTemplate)XamlReader.Parse(palette(itemXaml))));
            separator=new Style(typeof(Separator));
            separator.Setters.Add(new Setter(Control.TemplateProperty,(ControlTemplate)XamlReader.Parse(palette(@"<ControlTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' TargetType='Separator'><Border Height='1' Background='@LINE' Margin='8,5'/></ControlTemplate>"))));
            menu=new Style(typeof(ContextMenu));
            menu.Setters.Add(new Setter(Control.ForegroundProperty,Polish.Ink(light)));
            menu.Setters.Add(new Setter(Control.BackgroundProperty,Polish.Color(background)));
            menu.Setters.Add(new Setter(Control.FontSizeProperty,13.0));
            menu.Setters.Add(new Setter(Control.TemplateProperty,(ControlTemplate)XamlReader.Parse(palette(@"<ControlTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' TargetType='ContextMenu'><Border Background='{TemplateBinding Background}' BorderBrush='@LINE' BorderThickness='1' CornerRadius='10' Padding='5' SnapsToDevicePixels='True'><ScrollViewer CanContentScroll='True' MaxHeight='420' VerticalScrollBarVisibility='Auto' HorizontalScrollBarVisibility='Disabled'><ItemsPresenter Grid.IsSharedSizeScope='True'/></ScrollViewer></Border></ControlTemplate>"))));
            item.Seal();separator.Seal();menu.Seal();
        }
        static MenuTheme For(bool light){MenuTheme value;if(!themes.TryGetValue(light,out value)){value=new MenuTheme(light);themes[light]=value;}return value;}
        public static void Install(Window window,bool light){var theme=For(light);window.Resources[typeof(ContextMenu)]=theme.menu;window.Resources[typeof(MenuItem)]=theme.item;window.Resources[typeof(Separator)]=theme.separator;}
        public static ContextMenu Create(bool light){var theme=For(light);var value=new ContextMenu{Style=theme.menu};value.Resources[typeof(MenuItem)]=theme.item;value.Resources[typeof(Separator)]=theme.separator;return value;}
    }
}

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;using System.Windows.Media;using System.Windows.Media.Imaging;using System.Windows.Interop;

namespace GlassBoard {
    public sealed class RunningWindow {public IntPtr Handle;public uint ProcessId;public string Path,Title,FolderPath;}
    public static class RunningWindows {
        delegate bool Callback(IntPtr window,IntPtr value);
        [DllImport("user32.dll")] static extern bool EnumWindows(Callback callback,IntPtr value);
        [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr window);
        [DllImport("user32.dll")] static extern bool IsWindow(IntPtr window);
        [DllImport("user32.dll")] static extern bool IsIconic(IntPtr window);
        [DllImport("user32.dll")] static extern IntPtr GetWindow(IntPtr window,uint command);
        [DllImport("user32.dll",EntryPoint="GetWindowLongW")] static extern int GetWindowLong(IntPtr window,int index);
        [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr window,out uint id);
        [DllImport("user32.dll")] static extern bool ShowWindowAsync(IntPtr window,int command);
        [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] static extern IntPtr GetLastActivePopup(IntPtr window);
        [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr window,StringBuilder text,int length);
        [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr OpenProcess(uint access,bool inherit,uint id);
        [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool QueryFullProcessImageName(IntPtr process,uint flags,StringBuilder path,ref int length);
        [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
        [DllImport("dwmapi.dll")] static extern int DwmGetWindowAttribute(IntPtr window,int attribute,out int value,int size);
        [StructLayout(LayoutKind.Sequential)] struct FLASHWINFO{public uint Size;public IntPtr Window;public uint Flags,Count,Timeout;}
        [DllImport("user32.dll")] static extern bool FlashWindowEx(ref FLASHWINFO info);
        [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr window,StringBuilder text,int length);
        [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern IntPtr SendMessageTimeout(IntPtr window,uint message,IntPtr w,IntPtr l,uint flags,uint timeout,out IntPtr result);
        [DllImport("user32.dll",EntryPoint="GetClassLongPtrW")] static extern IntPtr ClassIcon64(IntPtr window,int index);
        [DllImport("user32.dll",EntryPoint="GetClassLongW")] static extern uint ClassIcon32(IntPtr window,int index);
        public static ImageSource Icon(RunningWindow window){
            try{IntPtr handle;SendMessageTimeout(window.Handle,0x7F,new IntPtr(1),IntPtr.Zero,2,80,out handle);
                if(handle==IntPtr.Zero)SendMessageTimeout(window.Handle,0x7F,new IntPtr(2),IntPtr.Zero,2,80,out handle);
                if(handle==IntPtr.Zero)handle=IntPtr.Size==8?ClassIcon64(window.Handle,-14):new IntPtr(unchecked((int)ClassIcon32(window.Handle,-14)));
                if(handle!=IntPtr.Zero){var image=Imaging.CreateBitmapSourceFromHIcon(handle,Int32Rect.Empty,BitmapSizeOptions.FromEmptyOptions());image.Freeze();return image;}
                if(!string.IsNullOrEmpty(window.Path)){var image=Native.Icon(window.Path);if(image!=null)return image;}
            }catch{}
            var fallback=Imaging.CreateBitmapSourceFromHIcon(System.Drawing.SystemIcons.Application.Handle,Int32Rect.Empty,BitmapSizeOptions.FromEmptyOptions());fallback.Freeze();return fallback;
        }
        sealed class TargetInfo {public DateTime Stamp;public string Target,Arguments;}
        static DateTime foldersAt=DateTime.MinValue;static Dictionary<long,string> folders=new Dictionary<long,string>();
        static readonly List<RunningWindow> windows=new List<RunningWindow>();
        static readonly BoundedCache<string,TargetInfo> targets=new BoundedCache<string,TargetInfo>(192,StringComparer.OrdinalIgnoreCase);
        static readonly BoundedCache<string,long> last=new BoundedCache<string,long>(192,StringComparer.OrdinalIgnoreCase);
        public static string ProcessPath(uint id){
            var process=OpenProcess(0x1000,false,id);if(process==IntPtr.Zero)return null;
            try{int length=512;var path=new StringBuilder(length);if(!QueryFullProcessImageName(process,0,path,ref length)){if(Marshal.GetLastWin32Error()!=122)return null;length=32768;path=new StringBuilder(length);if(!QueryFullProcessImageName(process,0,path,ref length))return null;}return WindowActivationRules.NormalizePath(path.ToString());}finally{CloseHandle(process);}
        }
        public static void Scan(){
            windows.Clear();if((DateTime.UtcNow-foldersAt).TotalSeconds>=3){foldersAt=DateTime.UtcNow;folders=ExplorerWindows.Read();}var byPid=new Dictionary<uint,string>();int own=Process.GetCurrentProcess().Id;
            EnumWindows((handle,value)=>{
                if(!IsWindowVisible(handle))return true;int style=GetWindowLong(handle,-20);if((style&0x80)!=0||((style&0x40000)==0&&GetWindow(handle,4)!=IntPtr.Zero&&IsWindowVisible(GetWindow(handle,4))))return true;
                int cloaked;try{if(DwmGetWindowAttribute(handle,14,out cloaked,4)==0&&cloaked!=0)return true;}catch{}
                uint id;GetWindowThreadProcessId(handle,out id);if(id==own)return true;string path;
                if(!byPid.TryGetValue(id,out path)){try{path=ProcessPath(id);}catch{path=null;}byPid[id]=path;}
                var text=new StringBuilder(1024);GetWindowText(handle,text,text.Capacity);if(string.IsNullOrWhiteSpace(text.ToString()))return true;
                var cls=new StringBuilder(128);GetClassName(handle,cls,cls.Capacity);if(new[]{"Progman","WorkerW","Shell_TrayWnd","Shell_SecondaryTrayWnd"}.Contains(cls.ToString()))return true;
                string folder;folders.TryGetValue(handle.ToInt64(),out folder);windows.Add(new RunningWindow{Handle=handle,ProcessId=id,Path=path,Title=text.ToString(),FolderPath=folder});return true;
            },IntPtr.Zero);
        }
        static void Resolve(Entry entry){
            if(entry==null||entry.IsFolder)return;string path=entry.Path;if(string.IsNullOrEmpty(path))return;
            if(!Path.GetExtension(path).Equals(".lnk",StringComparison.OrdinalIgnoreCase)){if(string.IsNullOrWhiteSpace(entry.LaunchTarget))LaunchInfoService.Enrich(entry);return;}
            DateTime stamp;try{stamp=File.GetLastWriteTimeUtc(path);}catch{stamp=DateTime.MinValue;}TargetInfo cached;
            if(targets.TryGet(path,out cached)&&cached.Stamp==stamp){entry.LaunchTarget=cached.Target;entry.LaunchArguments=cached.Arguments;return;}
            LaunchInfoService.Enrich(entry);targets.Put(path,new TargetInfo{Stamp=stamp,Target=entry.LaunchTarget,Arguments=entry.LaunchArguments});
        }
        public static List<RunningWindow> For(Entry entry){if(entry==null)return new List<RunningWindow>();if(entry.IsFolder||Directory.Exists(entry.Path)){string folder=EntryPathRules.Normalize(entry.Path);return windows.Where(w=>!string.IsNullOrEmpty(w.FolderPath)&&string.Equals(w.FolderPath,folder,StringComparison.OrdinalIgnoreCase)).ToList();}Resolve(entry);var paths=WindowActivationRules.Executables(entry);return windows.Where(w=>paths.Contains(w.Path,StringComparer.OrdinalIgnoreCase)).OrderBy(w=>w.Handle.ToInt64()).ToList();}
        public static List<RunningWindow> Snapshot(){return windows.ToList();}
        public static bool IsRunning(Entry entry){return For(entry).Count>0;}
        [DllImport("user32.dll",SetLastError=true)]static extern bool PostMessage(IntPtr window,uint message,IntPtr w,IntPtr l);
        public static bool RequestClose(RunningWindow window){if(window==null||!IsWindow(window.Handle))return false;uint pid;GetWindowThreadProcessId(window.Handle,out pid);if(pid!=window.ProcessId)return false;return PostMessage(window.Handle,0x10,IntPtr.Zero,IntPtr.Zero);}
        public static bool ActivateHandle(IntPtr handle){
            if(!IsWindow(handle))return false;if(IsIconic(handle))ShowWindowAsync(handle,9);
            var popup=GetLastActivePopup(handle);var target=popup!=IntPtr.Zero&&IsWindowVisible(popup)?popup:handle;
            if(!Native.SetForegroundWindow(target)){var flash=new FLASHWINFO{Size=(uint)Marshal.SizeOf(typeof(FLASHWINFO)),Window=target,Flags=3,Count=2};FlashWindowEx(ref flash);Store.Trace("WINDOW_SWITCH foreground request blocked handle="+target);}
            // A recognized existing window must never fall through to launching
            // another instance merely because Windows refused foreground focus.
            return true;
        }
        public static bool Activate(Entry entry){
            Scan();var matches=For(entry);if(matches.Count==0)return false;var foreground=GetForegroundWindow();uint pid;GetWindowThreadProcessId(foreground,out pid);long previous;last.TryGet(entry.Path,out previous);
            long selected=WindowActivationRules.Select(matches.Select(w=>w.Handle.ToInt64()),foreground.ToInt64(),previous,pid==(uint)Process.GetCurrentProcess().Id);var handle=new IntPtr(selected);
            if(!ActivateHandle(handle))return false;last.Put(entry.Path,selected);return true;
        }
    }
}

﻿# Isolated native supplement. No network, player files or account access.
$ErrorActionPreference='Stop'
$pipeInput=New-Object IO.StreamReader([Console]::OpenStandardInput(),(New-Object Text.UTF8Encoding($false,$true)))
$pipeOutput=New-Object IO.StreamWriter([Console]::OpenStandardOutput(),(New-Object Text.UTF8Encoding($false)))
$pipeOutput.AutoFlush=$true
[Console]::SetIn($pipeInput)
[Console]::SetOut($pipeOutput)
$npsm=$null;$startupError=$null
try{Add-Type -Path (Join-Path $PSScriptRoot '..\lib\NPSMLib.dll');$npsm=New-Object NPSMLib.NowPlayingSessionManager}catch{$startupError=$_.Exception.Message}
function Close-Safely($value) { try { if ($null -ne $value -and $value -is [IDisposable]) { ([IDisposable]$value).Dispose() } } catch { } }
function Get-TimelineSafely($session) {
    try { return $session.GetTimelineProperties() } catch {
        return [pscustomobject]@{ StartTime=[TimeSpan]::Zero; EndTime=[TimeSpan]::Zero; Position=[TimeSpan]::Zero; MinSeekTime=[TimeSpan]::Zero; MaxSeekTime=[TimeSpan]::Zero; LastUpdatedTime=[DateTimeOffset]::UtcNow; Error=$_.Exception.Message }
    }
}
function Same-MediaText($left,$right) { return $left -and $right -and ([string]$left).Trim().Normalize().Equals(([string]$right).Trim().Normalize(),[StringComparison]::OrdinalIgnoreCase) }
function Find-NativeMedia($source, $title, $artist) {
    $script:nativeObserved=New-Object Collections.Generic.List[string]
    if ($null -eq $npsm) { return $null }
    try {
        foreach ($candidate in $npsm.GetSessions()) {
            try {
                $data = $candidate.ActivateMediaPlaybackDataSource()
                $info = $data.GetMediaObjectInfo()
                $app="";try{$app = [string]$data.GetParentApplicationId()}catch{}
                if($script:nativeObserved.Count -lt 4){$script:nativeObserved.Add($app+" / "+[string]$info.Title)}
                $sameSource = $source -and $app -and $app.Equals($source, [StringComparison]::OrdinalIgnoreCase)
                if (-not $sameSource -and $source) {
                    try { $proc = [Diagnostics.Process]::GetProcessById([int]$candidate.PID);try { $name=$proc.ProcessName; $sameSource=$name.Length -ge 3 -and $source.IndexOf($name,[StringComparison]::OrdinalIgnoreCase) -ge 0 } finally { $proc.Dispose() } } catch {}
                }
                $sameSong = Same-MediaText $title $info.Title
                if ($title -and $info.Title -and -not $sameSong) { continue }
                if ($sameSource -or ($sameSong -and $artist -and (Same-MediaText $info.Artist $artist))) { return $data }
            } catch { }
        }
    } catch { }
    return $null
}

while($null -ne ($line=[Console]::ReadLine())){
 try{
  $request=$line|ConvertFrom-Json
  if($request.Command -eq 'exit'){break}
  if($startupError){throw $startupError}
  $native=Find-NativeMedia ([string]$request.Source) ([string]$request.Title) ([string]$request.Artist)
  if($null -eq $native){throw ('No matching native session; observed: '+($script:nativeObserved -join '; '))}
  $info=$native.GetMediaObjectInfo()
  $expected=[string]$request.Source+'|'+[string]$request.Title+'|'+[string]$request.Artist+'|'+[string]$request.Album
  if(-not $request.Source -or -not $request.Key -or [string]$request.Key -ne $expected){throw 'Session identity mismatch'}
  if($request.Title -and $info.Title -and -not (Same-MediaText $request.Title $info.Title)){throw 'Track changed'}
  $duration=0.0;$position=0.0;$minimum=0.0;$maximum=0.0;$age=0.0;$rate=1.0;$canSeek=$false;$timelineStatus='Not supplied'
  if(-not $request.CoverOnly){try{
   $timeline=$native.GetMediaTimelineProperties();$playback=$native.GetMediaPlaybackInfo()
   $duration=[Math]::Max(0,($timeline.EndTime-$timeline.StartTime).TotalSeconds)
   $position=[Math]::Max(0,($timeline.Position-$timeline.StartTime).TotalSeconds)
   $minimum=[Math]::Max(0,($timeline.MinSeekTime-$timeline.StartTime).TotalSeconds)
   $maximum=[Math]::Min($duration,[Math]::Max(0,($timeline.MaxSeekTime-$timeline.StartTime).TotalSeconds));if($maximum -le $minimum){$maximum=$duration}
   $canSeek=([int]$playback.PlaybackCaps -band [int][NPSMLib.MediaPlaybackCapabilities]::PlaybackPosition) -ne 0 -and $duration -gt 0
   if($playback.PlaybackRate -gt 0){$rate=[double]$playback.PlaybackRate}
   try{if($timeline.PositionSetFileTime.Year -gt 2000){$age=[Math]::Max(0,[Math]::Min(86400,([DateTime]::UtcNow-$timeline.PositionSetFileTime.ToUniversalTime()).TotalSeconds))}}catch{}
   $timelineStatus=if($duration -gt 0){'OK'}else{'Not supplied'}
  }catch{$timelineStatus=$_.Exception.Message}}
  $status='OK'
  if($request.Command -eq 'seek'){
   if(-not $canSeek){$status='Player did not accept this action'}else{
    $seconds=[Math]::Max($minimum,[Math]::Min($maximum,[double]$request.Seconds))
    if($native.SendPlaybackPositionChangeRequest([TimeSpan]::FromTicks($timeline.StartTime.Ticks+[long]($seconds*10000000)))){$position=$seconds;$age=0.0}else{$status='Player did not accept this action'}
   }
  }
  $cover='';$coverStatus='Not supplied';$stream=$null;$memory=$null
  if($request.Command -ne 'seek'){
   try{$stream=$native.GetThumbnailStream();if($stream -and $stream.Length -gt 0 -and $stream.Length -le 8388608){$memory=New-Object IO.MemoryStream;$stream.CopyTo($memory);$cover=[Convert]::ToBase64String($memory.ToArray());$coverStatus='NPSMLib thumbnail'}}catch{$coverStatus=$_.Exception.Message}finally{Close-Safely $memory;Close-Safely $stream}
  }
  $reply=@{Available=$true;Status=$status;Key=[string]$request.Key;Source=[string]$request.Source;Title=[string]$info.Title;Artist=[string]$info.Artist;Album=[string]$info.AlbumTitle;Duration=$duration;Position=$position;MinSeek=$minimum;MaxSeek=$maximum;Age=$age;Rate=$rate;CanSeek=$canSeek;Cover=$cover;CoverStatus=$coverStatus;TimelineStatus=$timelineStatus;Backend='NPSMLib isolated'}
 }catch{$reply=@{Available=$false;Status=$_.Exception.Message;Key=[string]$request.Key;Cover=''}}
 [Console]::WriteLine(($reply|ConvertTo-Json -Compress -Depth 4));[Console]::Out.Flush()
}

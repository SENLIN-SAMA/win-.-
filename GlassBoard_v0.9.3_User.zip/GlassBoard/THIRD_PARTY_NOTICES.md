# 第三方组件

NPSMLib — ADeltaX，MIT 许可，固定版本 22616b82f9b6ffd43ecf863f89455766edf63c76。
项目地址：https://github.com/ADeltaX/NPSMLib
许可全文：licenses/NPSMLib_LICENSE.txt。运行库：lib/NPSMLib.dll。

网易云 COM 适配代码 — Widdit/now-playing-service，MIT 许可，固定版本 2336c5fc6c57300bc7cf5fa85c7f273042bb86b1，含本项目适配修改。
项目地址：https://github.com/Widdit/now-playing-service
许可全文：licenses/now-playing-service_LICENSE.txt。所需 Interop.UIAutomationClient.dll 随程序提供。
